<?php 
//    bah2 - bah audio handler - custom streaming internet audio
//    Copyright (C) 2005 Nathan Garretson

//    This program is free software; you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation; either version 2 of the License, or
//    (at your option) any later version.

//    This program is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.

//    You should have received a copy of the GNU General Public License
//    along with this program; if not, write to the Free Software
//    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

	session_start();
	error_reporting(E_ALL);
	
	// authenticate - get user and passwd
	function authenticate() {
	  header('WWW-Authenticate: Basic realm="bah2"');
	  header('HTTP/1.0 401 Unauthorized');
	  echo 'bah2 requires authentication to access.';
	  exit;
	}
	
	// first login otherwise (else) load include files check user info
	if (!isset($_SERVER["PHP_AUTH_USER"])) { 
		authenticate();
	}
	else {
		include("bah2.php");
		if (($_SERVER["PHP_AUTH_USER"] != USER) or ($_SERVER["PHP_AUTH_PW"] != PASSWD)) { authenticate(); }
	}

?>
<!DOCTYPE html PUBLIC "-//W3C/DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/transitional.dtd">	
<html xmlns="http://www/w3/org/TR/xhtml1">

<head>
	<title>bah2</title>
	<link rel="stylesheet" type="text/css" href="bah2.css" />
</head>

		
<body>

<div class="browse">
	<p class="boxtitle">browse ::</p>&nbsp;<?php echo buildPath(); ?>
	<br />
	<div class="listbox" id="browseBox"><?php fillBrowseWindow(); ?></div>
</div>
<div class="titlebox">
	<br /><br />
	<p class="title">bah2</p>
	<br />
	<p>
	:: nathan garretson<br />
	:: cis seminar fall 2003<br />
	</p>
	<br />
	<p class="weblink">http://bah.thesilentnoise.com</p>
	<br /><br />
	logged in as :: <?php echo $_SERVER["PHP_AUTH_USER"]; ?><br />
	<a href="logout.php" class="reglink">click here to logout</a><br />
	<br />
	<?php echo "<a href=\"m3u/" . $_SERVER["PHP_AUTH_USER"] . ".m3u\"><img src=\"icons/sound1.gif\">&nbsp;Listen to my stream!!</a>";  ?>
</div>
<div class="mylist">
	<p class="boxtitle">mylist ::</p>&nbsp;<?php echo "<a href=\"?listen=true\" class=\"reglink\"><img src=\"icons/sound1.gif\">&nbsp;" . $_SERVER["PHP_AUTH_USER"] . ".plist - click to launch stream</a>"; ?>
	<br />
	<div class="listbox" id="browseBox"><?php displayPlaylist(); ?></div>
</div>


</body>
</html>
