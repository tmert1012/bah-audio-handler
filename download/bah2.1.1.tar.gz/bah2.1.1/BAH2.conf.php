<?php
// *************************************************************************************
//	bah2 config file - included by bah2.php
//	nathan garretson
// EDIT THESE NEXT LINES, NO TRAILING "/"
define ("WEBDIR" , "/www/htdocs/bah2");
define ("MP3DIR" , "/mp3");
define ("LOGDIR", "/tmp");
define ("USER", "user");
define ("PASSWD", "pass");
// ICECAST/ICES RELATED
define ("ICESCMD" , "/usr/local/icecast/bin/ices");
define ("ICECAST_PASSWD", "pass");
define ("IP", "192.168.1.104");
define ("PORT", "8000");
define ("BITRATE", "64");
// IF THE BAH SERVER IS BEHIND AN IP FORWARDING FIREWALL, ie. SERVER IP IS A
// NON-ROUTEABLE ADDRESS, THEN ENTER THE EXTERNAL ADDRESS BELOW
// define ("EXT_IP", "");
// *************************************************************************************
?>


