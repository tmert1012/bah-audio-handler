<?php
//    bah2 - bah audio handler - custom streaming internet audio
//    Copyright (C) 2005 Nathan Garretson

//    This program is free software; you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation; either version 2 of the License, or
//    (at your option) any later version.

//    This program is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.

//    You should have received a copy of the GNU General Public License
//    along with this program; if not, write to the Free Software
//    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//*************************************************************************************
//	bah2 config file - included by bah2.php
//	nathan garretson
// EDIT THESE NEXT LINES, NO TRAILING "/"
define ("WEBDIR" , "/www/htdocs/bah2");
define ("MP3DIR" , "/mp3");
define ("LOGDIR", "/tmp");
define ("USER", "user");
define ("PASSWD", "userpass");
// ICECAST/ICES RELATED
define ("ICESCMD" , "/usr/local/icecast/bin/ices");
define ("ICECAST_PASSWD", "icepass");
define ("IP", "192.168.0.3");
define ("PORT", "8000");
define ("BITRATE", "128");

//*************************************************************************************
?>


